onPressed: () async {
  if (_amountController.text.isNotEmpty) {
    double amount = double.tryParse(_amountController.text) ?? 0.0;

    if (amount > 0) {
      setState(() {
        isLoading = true;
      });

      try {
        double exchangeRate = await ApiService.getExchangeRate(fromCurrency, toCurrency);

        setState(() {
          convertedAmount = amount * exchangeRate;
          isLoading = false;
        });
      } catch (error) {
        print("Error fetching exchange rate: $error");
        setState(() {
          isLoading = false;
        });
      }
    }
  }
}
