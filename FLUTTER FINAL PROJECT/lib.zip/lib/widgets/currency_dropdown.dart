import 'package:flutter/material.dart';
import '../utils/constants.dart';

class CurrencyDropdown extends StatelessWidget {
  final String selectedCurrency;
  final ValueChanged<String?> onChanged;

  CurrencyDropdown({required this.selectedCurrency, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return DropdownButton<String>(
      value: selectedCurrency,
      items: currencyList.map((currency) {
        return DropdownMenuItem(value: currency, child: Text(currency));
      }).toList(),
      onChanged: onChanged,
    );
  }
}
