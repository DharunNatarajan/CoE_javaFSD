import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String apiKey = "68986574b6bfa1a88a59dca9";  // Replace with your API Key
  static const String baseUrl = "https://v6.exchangerate-api.com/v6/$apiKey/latest";

  static Future<double> getExchangeRate(String from, String to) async {
    final response = await http.get(Uri.parse("$baseUrl/$from"));

    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      return data['conversion_rates'][to] ?? 1.0;
    } else {
      throw Exception('Failed to fetch exchange rate');
    }
  }
}
