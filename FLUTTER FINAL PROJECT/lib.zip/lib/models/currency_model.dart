class CurrencyModel {
  final String baseCurrency;
  final Map<String, double> rates;

  CurrencyModel({required this.baseCurrency, required this.rates});

  factory CurrencyModel.fromJson(Map<String, dynamic> json) {
    return CurrencyModel(
      baseCurrency: json['base_code'] ?? '',
      rates: Map<String, double>.from(json['conversion_rates'] ?? {}),
    );
  }
}
