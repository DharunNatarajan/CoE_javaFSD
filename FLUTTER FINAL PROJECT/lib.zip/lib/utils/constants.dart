const List<String> currencyList = [
  "USD", "INR", "EUR", "GBP", "JPY", "CAD", "AUD", "SGD"
];
