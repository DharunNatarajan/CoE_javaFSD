import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/api_service.dart';
import '../localization/app_localizations.dart';

class ConverterScreen extends StatefulWidget {
  const ConverterScreen({super.key});

  @override
  State<ConverterScreen> createState() => _ConverterScreenState();
}

class _ConverterScreenState extends State<ConverterScreen> {
  final TextEditingController _amountController = TextEditingController();
  String _fromCurrency = "USD";
  String _toCurrency = "INR";
  double _convertedAmount = 0.0;
  bool _isLoading = false;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final List<String> currencies = ["USD", "EUR", "INR", "GBP", "CAD", "AUD"];

  void _convertCurrency() async {
    double amount = double.tryParse(_amountController.text) ?? 0.0;
    if (amount > 0) {
      setState(() {
        _isLoading = true;
      });

      double exchangeRate = await ApiService.getExchangeRate(_fromCurrency, _toCurrency);
      double convertedAmount = double.parse((amount * exchangeRate).toStringAsFixed(2));
      
      setState(() {
        _convertedAmount = convertedAmount;
        _isLoading = false;
      });

      // Store conversion details in Firestore
      await _firestore.collection('conversions').add({
        'amount': amount,
        'fromCurrency': _fromCurrency,
        'toCurrency': _toCurrency,
        'convertedAmount': convertedAmount,
        'timestamp': FieldValue.serverTimestamp(),
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context).translate('currency_converter'))),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              AppLocalizations.of(context).translate('enter_amount'),
              style: const TextStyle(fontSize: 18, color: Colors.white),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: AppLocalizations.of(context).translate('enter_amount'),
                hintStyle: const TextStyle(color: Colors.white54),
                filled: true,
                fillColor: Colors.deepPurple.shade700,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildDropdown(AppLocalizations.of(context).translate('from'), _fromCurrency, (value) {
                  setState(() {
                    _fromCurrency = value!;
                  });
                }),
                const Icon(Icons.swap_horiz, color: Colors.white, size: 30),
                _buildDropdown(AppLocalizations.of(context).translate('to'), _toCurrency, (value) {
                  setState(() {
                    _toCurrency = value!;
                  });
                }),
              ],
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: _convertCurrency,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                foregroundColor: Colors.black,
              ),
              child: Text(AppLocalizations.of(context).translate('convert_button')),
            ),
            const SizedBox(height: 30),
            _isLoading
                ? const CircularProgressIndicator(color: Colors.white)
                : Text(
                    "${AppLocalizations.of(context).translate('converted_amount')} $_convertedAmount $_toCurrency",
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdown(String label, String selectedValue, ValueChanged<String?> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 16, color: Colors.white)),
        const SizedBox(height: 5),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            color: Colors.deepPurple.shade700,
            borderRadius: BorderRadius.circular(10),
          ),
          child: DropdownButton<String>(
            value: selectedValue,
            onChanged: onChanged,
            dropdownColor: Colors.deepPurple.shade800,
            iconEnabledColor: Colors.white,
            style: const TextStyle(color: Colors.white, fontSize: 16),
            underline: Container(),
            items: currencies.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value, style: const TextStyle(color: Colors.white)),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}
