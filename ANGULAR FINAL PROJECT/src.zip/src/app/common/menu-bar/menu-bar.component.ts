import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-menu-bar',
  templateUrl: './menu-bar.component.html',
  styleUrls: ['./menu-bar.component.css']
})
export class MenuBarComponent {
  isLoggedIn: boolean = false;
  searchQuery: string = '';  
  productCategories: string[] = ['laptops', 'mobiles', 'accessories', 'gaming']; 
  filteredResults: string[] = []; 

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {
    // Subscribe to login state changes
    this.authService.isLoggedIn$.subscribe(status => {
      this.isLoggedIn = status;
    });
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/']); 
  }

  // Filter search suggestions dynamically
  filterSearchResults(): void {
    if (!this.searchQuery.trim()) {
      this.filteredResults = [];
      return;
    }

    this.filteredResults = this.productCategories.filter(category =>
      category.toLowerCase().includes(this.searchQuery.toLowerCase())
    );
  }

  // Navigate to the selected category
  navigateToCategory(category: string): void {
    this.searchQuery = category; // Set search input
    this.filteredResults = []; // Hide dropdown
    this.router.navigate([`/${category}`]); // Navigate to category page
  }

  // Handle search button click
  searchProducts(): void {
    if (!this.searchQuery.trim()) return;

    const matchedCategory = this.productCategories.find(category =>
      category.toLowerCase() === this.searchQuery.toLowerCase()
    );

    if (matchedCategory) {
      this.router.navigate([`/${matchedCategory}`]); // Redirect to the matched category page
    } else {
      alert('No matching category found!'); // Handle invalid queries
    }
  }
}
