import { Component, OnInit } from '@angular/core';
import { CartService } from '../../services/cart.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems: any[] = [];
  isLoggedIn: boolean = false;

  constructor(private cartService: CartService, private authService: AuthService) {}

  ngOnInit(): void {
    // Subscribe to authentication state
    this.authService.isLoggedIn$.subscribe(status => {
      this.isLoggedIn = status;
    });

    // Fetch cart items from localStorage
    this.cartService.getCartItems().subscribe((items) => {
      this.cartItems = items;
    });
  }

  // Clear the cart manually (button)
  clearCart(): void {
    this.cartService.clearCart();
  }
}
