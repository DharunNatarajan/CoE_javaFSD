import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuBarComponent } from './common/menu-bar/menu-bar.component';
import { HomeComponent } from './pages/home/home.component';
import { ContactComponent } from './pages/contact/contact.component';
import { AboutComponent } from './pages/about/about.component';
import { LaptopsComponent } from './pages/product/laptops/laptops.component';
import { MobilesComponent } from './pages/product/mobiles/mobiles.component';
import { AccessoriesComponent } from './pages/product/accessories/accessories.component';
import { GamingComponent } from './pages/product/gaming/gaming.component';
import { OffersComponent } from './pages/offers/offers.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CartComponent } from './common/cart/cart.component';
import { LoginComponent } from './common/login/login.component';
import { DiscountPricePipe } from './pipes/discount-price.pipe';
import { MyOrdersComponent } from './pages/my-orders/my-orders.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuBarComponent,
    HomeComponent,
    ContactComponent,
    AboutComponent,
    LaptopsComponent,
    MobilesComponent,
    AccessoriesComponent,
    GamingComponent,
    OffersComponent,
    CartComponent,
    LoginComponent,
    DiscountPricePipe,
    MyOrdersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
