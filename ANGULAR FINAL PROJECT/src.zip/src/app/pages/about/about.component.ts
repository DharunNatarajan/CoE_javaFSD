import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { About } from '../../model/about';


@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrl: './about.component.css'
})
export class AboutComponent {
  aboutInfo: About = {
    title: "Welcome to Volt & Vision – Your One-Stop Electronics Store!",
    description: "At Volt & Vision, we bring you the latest and most innovative electronic gadgets, ensuring you stay ahead in the digital world. From high-performance laptops and gaming accessories to the latest smartphones and home automation devices, we have everything you need to enhance your tech experience.",
    image: "assets/images/about-us.jpg"
  };
}
