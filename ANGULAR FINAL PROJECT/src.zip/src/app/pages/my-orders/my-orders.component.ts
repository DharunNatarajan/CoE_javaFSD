import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.css']
})
export class MyOrdersComponent implements OnInit {
  orderItems: any[] = []; // ✅ Keep order items array
  isLoggedIn = false; // ✅ Track user login status

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    // ✅ Subscribe to login status
    this.authService.isLoggedIn$.subscribe((status) => {
      this.isLoggedIn = status;
      if (this.isLoggedIn) {
        this.loadOrders(); // ✅ Load orders when logged in
      } else {
        this.orderItems = []; // ✅ Clear orders when logged out
      }
    });
  }

  // ✅ Load orders safely from localStorage
  loadOrders(): void {
    const savedOrders = localStorage.getItem('myOrders');
    this.orderItems = savedOrders ? JSON.parse(savedOrders) : [];
  }

  // ✅ Clear My Orders
  clearOrders(): void {
    localStorage.removeItem('myOrders');
    this.orderItems = [];
  }
}
