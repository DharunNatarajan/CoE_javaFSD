import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { Mobile } from '../../../model/mobile';
import { CartService } from '../../../services/cart.service';
import { Router } from '@angular/router'; // Import Router

@Component({
  selector: 'app-mobiles',
  templateUrl: './mobiles.component.html',
  styleUrls: ['./mobiles.component.css']
})
export class MobilesComponent implements OnInit {
  mobiles: Mobile[] = [];

  constructor(
    private apiService: ApiService,
    private cartService: CartService,
    private router: Router // Inject Router
  ) {}

  ngOnInit(): void {
    this.apiService.getMobiles().subscribe(
      (data) => {
        console.log('Fetched mobiles:', data);
        this.mobiles = data;
      },
      (error) => {
        console.error('Error fetching mobiles:', error);
      }
    );
  }

  // ✅ Add to Cart Functionality
  addToCart(mobile: Mobile): void {
    this.cartService.addToCart(mobile);
    alert(`${mobile.name} added to cart!`);
  }

  // ✅ Buy Now Functionality (Add to MyOrders and Redirect)
  buyNow(mobile: Mobile): void {
    let orders = localStorage.getItem('myOrders');
    let orderList = orders ? JSON.parse(orders) : [];

    orderList.push(mobile);
    localStorage.setItem('myOrders', JSON.stringify(orderList));

    alert(`${mobile.name} purchased successfully!`);
  }
}
