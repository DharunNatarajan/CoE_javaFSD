import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { Accessory } from '../../../model/accessory';
import { CartService } from '../../../services/cart.service';  
import { Router } from '@angular/router'; // ✅ Import Router for navigation

@Component({
  selector: 'app-accessories',
  templateUrl: './accessories.component.html',
  styleUrls: ['./accessories.component.css']
})
export class AccessoriesComponent implements OnInit {
  accessories: Accessory[] = [];

  constructor(
    private apiService: ApiService, 
    private cartService: CartService,
    private router: Router // ✅ Inject Router for redirection
  ) {}

  ngOnInit(): void {
    this.apiService.getAccessories().subscribe(
      (data: Accessory[]) => {
        this.accessories = data;
      },
      (error) => {
        console.error('Error fetching accessories:', error);
      }
    );
  }

  // ✅ Add to Cart Functionality
  addToCart(accessory: Accessory): void {
    this.cartService.addToCart(accessory);
    alert(`${accessory.name} added to cart!`);
  }

  // ✅ Buy Now Functionality
  buyNow(accessory: Accessory): void {
    let myOrders = localStorage.getItem('myOrders');
    let orders = myOrders ? JSON.parse(myOrders) : [];

    orders.push(accessory); // Add the selected accessory to orders
    localStorage.setItem('myOrders', JSON.stringify(orders)); // Save updated orders

    alert(`${accessory.name} purchased successfully!`);
  }
}
