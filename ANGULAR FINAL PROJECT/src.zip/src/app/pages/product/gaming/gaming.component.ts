import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../../../services/api.service';
import { GamingProduct } from '../../../model/gaming';
import { CartService } from '../../../services/cart.service';
import { AuthService } from '../../../services/auth.service'; // ✅ Import AuthService

@Component({
  selector: 'app-gaming',
  templateUrl: './gaming.component.html',
  styleUrls: ['./gaming.component.css']
})
export class GamingComponent implements OnInit {
  gamingProducts: GamingProduct[] = [];
  isLoggedIn = false; // ✅ Track login status

  constructor(
    private apiService: ApiService,
    private cartService: CartService,
    private authService: AuthService, // ✅ Inject AuthService
    private router: Router
  ) {}

  ngOnInit(): void {
    // ✅ Subscribe to login status
    this.authService.isLoggedIn$.subscribe((status) => {
      this.isLoggedIn = status;
    });

    // ✅ Fetch gaming products
    this.apiService.getGamingProducts().subscribe(
      (data: GamingProduct[]) => {
        this.gamingProducts = data;
      },
      (error) => {
        console.error('Error fetching gaming products:', error);
      }
    );
  }

  // ✅ Add item to cart
  addToCart(product: GamingProduct): void {
    this.cartService.addToCart(product);
    alert(`${product.name} has been added to the cart!`);
  }

  // ✅ Buy Now Functionality (Requires Login)
  buyNow(product: GamingProduct): void {
    if (!this.isLoggedIn) {
      alert('Please log in first to purchase this product!');
      this.router.navigate(['/login']); // ✅ Redirect to login page
      return;
    }

    let myOrders = localStorage.getItem('myOrders');
    let orders = myOrders ? JSON.parse(myOrders) : [];

    orders.push(product); // ✅ Add selected product to orders
    localStorage.setItem('myOrders', JSON.stringify(orders)); // ✅ Save to local storage

    alert(`${product.name} purchased successfully!`);
  }
}
