import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { CartService } from '../../../services/cart.service';
import { Laptop } from '../../../model/laptop';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service'; // ✅ Import AuthService

@Component({
  selector: 'app-laptops',
  templateUrl: './laptops.component.html',
  styleUrls: ['./laptops.component.css']
})
export class LaptopsComponent implements OnInit {
  laptops: Laptop[] = [];
  isLoggedIn = false; // ✅ Track login status

  constructor(
    private apiService: ApiService,
    private cartService: CartService,
    private authService: AuthService, // ✅ Inject AuthService
    private router: Router
  ) {}

  ngOnInit(): void {
    // ✅ Subscribe to login status
    this.authService.isLoggedIn$.subscribe((status) => {
      this.isLoggedIn = status;
    });

    // ✅ Fetch laptop products
    this.apiService.getLaptops().subscribe(
      (data) => {
        console.log('Fetched laptops:', data);
        this.laptops = data;
      },
      (error) => {
        console.error('Error fetching laptops:', error);
      }
    );
  }

  // ✅ Add selected laptop to cart
  addToCart(laptop: Laptop): void {
    this.cartService.addToCart(laptop);
    alert(`${laptop.name} added to cart!`);
  }

  // ✅ Buy Now Functionality (Requires Login)
  buyNow(laptop: Laptop): void {
    if (!this.isLoggedIn) {
      alert('Please log in first to purchase this product!');
      this.router.navigate(['/login']); // ✅ Redirect to login page
      return;
    }

    let myOrders = localStorage.getItem('myOrders');
    let orders = myOrders ? JSON.parse(myOrders) : [];

    orders.push(laptop); // ✅ Add selected laptop to orders
    localStorage.setItem('myOrders', JSON.stringify(orders)); // ✅ Save updated orders

    alert(`${laptop.name} purchased successfully!`);
  }
}
