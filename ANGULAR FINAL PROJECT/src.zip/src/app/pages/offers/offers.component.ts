import { Component } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Offer } from '../../model/offer';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.component.html',
  styleUrl: './offers.component.css'
})
export class OffersComponent {
  offers: Offer[] = [];

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.getOffers();
  }

  getOffers(): void {
    this.apiService.getOffers().subscribe((data: Offer[]) => {
      this.offers = data;
    });
  }
}
