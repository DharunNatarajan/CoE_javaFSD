import { Component } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Contact } from '../../model/contact';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css'
})
export class ContactComponent {

  contactData: Contact = {
    name: '',
    email: '',
    message: ''
  };

  successMessage: string = '';
  errorMessage: string = '';

  constructor(private apiService: ApiService) {}

  submitForm(): void {
    if (this.contactData.name && this.contactData.email && this.contactData.message) {
      this.apiService.sendContactForm(this.contactData).subscribe(
        response => {
          this.successMessage = 'Your message has been sent successfully!';
          this.errorMessage = '';
          this.contactData = { name: '', email: '', message: '' }; // Reset form
        },
        error => {
          this.errorMessage = 'Something went wrong. Please try again!';
          this.successMessage = '';
        }
      );
    } else {
      this.errorMessage = 'All fields are required!';
    }
  }
}

