import { DiscountPricePipe } from './discount-price.pipe';

describe('DiscountPricePipe', () => {
  it('create an instance', () => {
    const pipe = new DiscountPricePipe();
    expect(pipe).toBeTruthy();
  });
});
