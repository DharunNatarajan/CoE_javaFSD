import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'discountPrice'
})
export class DiscountPricePipe implements PipeTransform {
  transform(originalPrice: number, discount: number): string {
    if (!originalPrice || !discount || discount <= 0) {
      return `₹${originalPrice.toFixed(2)}`;
    }

    const discountedPrice = originalPrice - (originalPrice * discount) / 100;
    return `₹${discountedPrice.toFixed(2)} (After ${discount}% Off)`;
  }
}
