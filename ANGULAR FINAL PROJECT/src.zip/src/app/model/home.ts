export interface product{
    name:string,
    description:string,
    image:string
}