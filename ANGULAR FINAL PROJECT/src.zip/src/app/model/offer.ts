export interface Offer {
    title: string;
    description: string;
    discount: number;
  }
  