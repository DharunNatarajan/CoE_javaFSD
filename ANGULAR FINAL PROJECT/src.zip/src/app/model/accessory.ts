export interface Accessory {
    id: number;
    name: string;
    brand: string;
    price: number;
    image: string;
    description: string;
    discount : number;
  }
  