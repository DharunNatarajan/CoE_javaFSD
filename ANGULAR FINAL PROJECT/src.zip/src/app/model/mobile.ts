export interface Mobile {
    id: number;
    name: string;
    brand: string;
    price: number;
    image: string;
    description: string;
    discount : number;
  }
