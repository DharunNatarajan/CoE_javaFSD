export interface About {
    title: string;
    description: string;
    image: string;
  }
  