import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loggedIn = new BehaviorSubject<boolean>(false);
  isLoggedIn$ = this.loggedIn.asObservable();

  constructor() {
    const user = localStorage.getItem('user');
    if (user) {
      this.loggedIn.next(true);
    }
  }

  login(): void {
    localStorage.setItem('user', 'true');
    this.loggedIn.next(true);
  }

  logout(): void {
    localStorage.removeItem('user'); // Do NOT clear cart
    this.loggedIn.next(false);
  }
}
