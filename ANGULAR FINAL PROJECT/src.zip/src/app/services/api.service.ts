import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Contact } from '../model/contact';
import { About } from '../model/about';
import { Laptop } from '../model/laptop';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = 'api.json';

  constructor(private http: HttpClient) {}


  getProducts(): Observable<any> {
    return this.http.get('http://localhost:4500/product');
  }

  getOffers(): Observable<any> {
    return this.http.get('http://localhost:4500/offers');
  }

  sendContactForm(contactData: Contact): Observable<any> {
    return this.http.post<any>('http://localhost:4500/Contact', contactData);
  }

  getLaptops(): Observable<any> {
    return this.http.get('http://localhost:4500/laptops');
  }

  getMobiles(): Observable<any> {
    return this.http.get('http://localhost:4500/mobiles');
  }

  getAccessories(): Observable<any> {
    return this.http.get('http://localhost:4500/accessories');
  }
  
  getGamingProducts(): Observable<any> {
    return this.http.get('http://localhost:4500/gamingProducts');
  }
}
