import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartItems = new BehaviorSubject<any[]>(this.getCartFromLocalStorage());

  constructor() {}

  private getCartFromLocalStorage(): any[] {
    const cart = localStorage.getItem('cart');
    return cart ? JSON.parse(cart) : [];
  }

  private saveCartToLocalStorage(cart: any[]): void {
    localStorage.setItem('cart', JSON.stringify(cart));
  }

  getCartItems(): Observable<any[]> {
    return this.cartItems.asObservable();
  }

  addToCart(product: any): void {
    const currentCart = this.getCartFromLocalStorage();
    currentCart.push(product);
    this.saveCartToLocalStorage(currentCart);
    this.cartItems.next(currentCart);
  }

  clearCart(): void {
    localStorage.removeItem('cart');  // Remove cart from localStorage
    this.cartItems.next([]); // Update observable
  }
}
