import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { ContactComponent } from './pages/contact/contact.component';
import { AboutComponent } from './pages/about/about.component';
import { LaptopsComponent} from './pages/product/laptops/laptops.component';
import { MobilesComponent } from './pages/product/mobiles/mobiles.component';
import { GamingComponent } from './pages/product/gaming/gaming.component';
import { AccessoriesComponent } from './pages/product/accessories/accessories.component';
import { OffersComponent} from './pages/offers/offers.component';
import { CartComponent } from './common/cart/cart.component';
import { LoginComponent } from './common/login/login.component';
import { MyOrdersComponent } from './pages/my-orders/my-orders.component';
import { authGuard } from './guards/auth.guard';

const routes: Routes = [
  {path : '', component : HomeComponent},
  {path : 'contact', component: ContactComponent },
  {path : 'about', component: AboutComponent },
  {path : 'laptops', component : LaptopsComponent},
  {path : 'mobiles', component : MobilesComponent},
  {path : 'gaming', component : GamingComponent},
  {path : 'accessories', component : AccessoriesComponent},
  {path : 'offers', component : OffersComponent},
  {path : 'cart', component : CartComponent},
  {path : 'login', component : LoginComponent},
  {path : 'my-orders', component : MyOrdersComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
